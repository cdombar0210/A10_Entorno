package ad10;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		String[] testCases = {
//		        "XIV",     // 14 → válido
//		        "MCMXC",   // 1990 → válido
//		        "IIII",    // inválido: I repetida 4 veces
//		        "IC",      // inválido: I no puede ir antes de C
//		        "XXL",     // inválido: X no puede restar a L así
//		        "MMM",     // 3000 → válido
//		        "VV",      // inválido: V no se puede repetir
//		        "ABC",     // inválido: letras desconocidas
//		        "XLIX",    // 49 → válido
//		        "CDXC",    // 490 → válido
//		        "DCCC",    // 800 → válido
//		    };
//
//		    for (String romano : testCases) {
//		        System.out.print("Número romano: " + romano + " → ");
//		        if (!EscritoBien(romano)) {
//		            System.out.println("Número inválido");
//		        } else {
//		            int valor = RomanoAEntero(romano);
//		            System.out.println("Valor entero: " + valor);
//		        }
//		    }
		    Scanner sc = new Scanner(System.in);

		    System.out.print("Introduce un número romano: ");
		    String romano1 = sc.nextLine();
		    System.out.print("Introduce otro número romano: ");
		    String romano2 = sc.nextLine();

		    if (!EscritoBien(romano1) || !EscritoBien(romano2)) {
		        System.out.println("Número inválido");
		        sc.close();
		        return; // termina el programa,para que no siga contando
		    }

		    int valor1 = RomanoAEntero(romano1);
		    int valor2 = RomanoAEntero(romano2);
		    if(valor1>valor2) {
		    	System.out.println("El primer valor es mayor que el segundo");
		    }
		    else if(valor1==valor2) {
		    	System.out.println("Son iguales");
		    }
		    else {
		    	System.out.println("El primer valor es menor que el segundo");
		    }
		    sc.close();

	}
	
	public static boolean EscritoBien(String romano) {
		Map<Character, Integer> romanos = new HashMap<>();

        romanos.put('I', 1);
        romanos.put('V', 5);
        romanos.put('X', 10);
        romanos.put('L', 50);
        romanos.put('C', 100);
        romanos.put('D', 500);
        romanos.put('M', 1000);
		if (romano.length() == 0) return false;

		int repeticiones = 1; // para contar repeticiones consecutivas

        for (int i = 0; i < romano.length(); i++) {
            char actual = romano.charAt(i);

            // Validar letra desconocida
            if ("IVXLCDM".indexOf(actual) == -1) return false;

            // Comprobar repeticiones
            if (i > 0) {
                char anterior = romano.charAt(i - 1);

                if (actual == anterior) {
                    repeticiones++;
                    // Letras que no pueden repetirse
                    if ("VLD".indexOf(actual) != -1 || repeticiones > 3) return false;
                } else {
                    repeticiones = 1; // reiniciar contador
                }

                // Validar pares para reglas de resta
                if (romanos.get(actual) > romanos.get(anterior)) {

                	if (i > 1 && romano.charAt(i - 2) == anterior) return false;

                    boolean valido = false;
                    switch (anterior) {
                        case 'I': valido = (actual == 'V' || actual == 'X'); break;
                        case 'X': valido = (actual == 'L' || actual == 'C'); break;
                        case 'C': valido = (actual == 'D' || actual == 'M'); break;
                        default: return false;
                    }
                    if (!valido) return false;
                }
            }
        }
        return true;
		
	}
	
	public static int RomanoAEntero(String romano) {
		Map<Character, Integer> romanos = new HashMap<>();

        romanos.put('I', 1);
        romanos.put('V', 5);
        romanos.put('X', 10);
        romanos.put('L', 50);
        romanos.put('C', 100);
        romanos.put('D', 500);
        romanos.put('M', 1000);
		int res=0,i;
		for(i=0;i<romano.length()-1;i++) {
			char letra1=romano.charAt(i);
			char letra2=romano.charAt(i+1);
			if (romanos.get(letra1) < romanos.get(letra2)) {
				res=res-romanos.get(letra1);
			}
			else {
				res=res+romanos.get(letra1);
			}
		}
		res=res+romanos.get(romano.charAt(i));
		return res;
		
	}
}
